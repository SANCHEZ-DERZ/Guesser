// Функция для обработки голосовых команд
function handleVoiceCommand(command) {
    if (command.includes("показать флаг")) {
        showFlag();
    } else if (command.includes("следующий флаг")) {
        nextFlag();
    } else if (command.includes("подсказка")) {
        showHint();
    } else if (command.includes("ответ")) {
        const answer = command.split("ответ")[1].trim();
        checkAnswer(answer);
    }
}

// Функция для инициализации голосового помощника
function initVoiceAssistant() {
    if (typeof $jsapi !== 'undefined') {
        $jsapi.onReady(function() {
            $jsapi.onMessage(function(message) {
                if (message.type === 'voice_command') {
                    handleVoiceCommand(message.text);
                }
            });
        });
    }
}

// Функция для отправки ответа в голосовой помощник
function sendAnswerToAssistant(answer) {
    if (typeof $jsapi !== 'undefined') {
        $jsapi.sendMessage({
            type: 'answer',
            text: answer
        });
    }
}

// Функция для сохранения состояния игры
function saveGameState() {
    if (typeof $session !== 'undefined') {
        $session.set('currentFlagIndex', currentFlagIndex);
        $session.set('score', score);
    }
}

// Функция для загрузки состояния игры
function loadGameState() {
    if (typeof $session !== 'undefined') {
        currentFlagIndex = $session.get('currentFlagIndex') || 0;
        score = $session.get('score') || 0;
        updateScore();
        showFlag();
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    initVoiceAssistant();
    loadGameState();
    showFlag();
}); 